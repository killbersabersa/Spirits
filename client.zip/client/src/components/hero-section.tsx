import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ChevronDown } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="min-h-screen flex items-center hero-bg relative overflow-hidden" data-testid="hero-section">
      <div className="absolute inset-0 gradient-overlay"></div>
      <div 
        className="absolute inset-0 bg-cover bg-center" 
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')"
        }}
      ></div>
      <div className="absolute inset-0 gradient-overlay"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl animate-fade-in">
          <h1 className="text-6xl md:text-8xl font-serif mb-6 leading-tight" data-testid="hero-title">
            Premium
            <span className="text-primary"> Kazakhstani</span>
            <br />
            Spirits
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl" data-testid="hero-description">
            78 years of craftsmanship. Award-winning vodkas from the endless steppes of Kazakhstan. 
            Discover Taigun, Aqqu, and Uly Dala.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/products">
              <Button className="btn-primary" data-testid="hero-button-products">
                Explore Products
              </Button>
            </Link>
            <Link href="/awards">
              <Button variant="outline" className="btn-secondary" data-testid="hero-button-awards">
                View Awards
              </Button>
            </Link>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce" data-testid="scroll-indicator">
        <ChevronDown className="text-accent text-2xl" />
      </div>
    </section>
  );
}
