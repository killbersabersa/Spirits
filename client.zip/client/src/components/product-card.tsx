import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { type Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const hasAwards = product.awards && product.awards.length > 0;
  const goldAward = product.awards?.find(award => award.medal.toLowerCase().includes('gold'));

  return (
    <Card className="bg-background rounded-xl overflow-hidden shadow-xl border border-border premium-card-hover group" data-testid={`product-card-${product.slug}`}>
      <div className="h-80 bg-cover bg-center relative" style={{ backgroundImage: `url('${product.imageUrl}')` }}>
        {hasAwards && (
          <div className="absolute top-4 right-4">
            {goldAward ? (
              <Badge className="bg-primary text-primary-foreground" data-testid={`award-badge-${product.slug}`}>
                🏆 Gold Medal
              </Badge>
            ) : (
              <Badge variant="secondary" data-testid={`award-badge-${product.slug}`}>
                Award Winner
              </Badge>
            )}
          </div>
        )}
        {product.isOrganic && (
          <div className="absolute top-4 left-4">
            <Badge variant="outline" className="bg-background/80" data-testid={`organic-badge-${product.slug}`}>
              Organic
            </Badge>
          </div>
        )}
      </div>
      <CardContent className="p-6">
        <h3 className="text-2xl font-serif mb-2 text-primary" data-testid={`product-title-${product.slug}`}>
          {product.name}
        </h3>
        <p className="text-muted-foreground mb-4" data-testid={`product-description-${product.slug}`}>
          {product.shortDescription}
        </p>
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground" data-testid={`product-specs-${product.slug}`}>
            {product.abv} ABV | {product.category}
          </span>
          <Link 
            href={`/products/${product.slug}`}
            className="text-primary hover:text-primary/80 font-medium transition-colors"
            data-testid={`product-link-${product.slug}`}
          >
            Learn More →
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
