import { useQuery } from "@tanstack/react-query";
import ProductCard from "@/components/product-card";
import { type Product } from "@shared/schema";

export default function Products() {
  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  return (
    <div className="pt-32 pb-20" data-testid="products-page">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-6xl font-serif mb-4" data-testid="products-page-title">
            Our Premium Collection
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="products-page-description">
            Discover our award-winning vodkas, each crafted with 78 years of heritage and the finest ingredients from Kazakhstan.
          </p>
        </div>

        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8" data-testid="products-loading">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-card rounded-xl h-96 animate-pulse" />
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-16" data-testid="products-empty-state">
            <h3 className="text-2xl font-serif mb-4">No Products Available</h3>
            <p className="text-muted-foreground">Our premium collection is currently being updated. Please check back soon.</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8" data-testid="products-grid">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
