import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Wheat, Cog, Leaf, Factory, Award, Globe } from "lucide-react";

export default function Heritage() {
  const { data: companyInfo, isLoading } = useQuery({
    queryKey: ["/api/company"],
  });

  const productionSteps = [
    {
      icon: <Wheat className="h-8 w-8 text-primary" />,
      title: "Premium Grains",
      description: "High-quality wheat from Kazakhstan's finest fields, carefully selected for optimal flavor"
    },
    {
      icon: <Factory className="h-8 w-8 text-primary" />,
      title: "Fermentation",
      description: "Controlled fermentation process with continuous monitoring for optimal flavor development"
    },
    {
      icon: <Cog className="h-8 w-8 text-primary" />,
      title: "Distillation",
      description: "30-meter distillation columns ensure ultimate purity and remove all impurities"
    },
    {
      icon: <Leaf className="h-8 w-8 text-primary" />,
      title: "Filtration",
      description: "Advanced carbon filtration and nano-filtration for crystal clear quality"
    }
  ];

  return (
    <div className="pt-32 pb-20" data-testid="heritage-page">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-6xl font-serif mb-4" data-testid="heritage-page-title">
            Our Heritage
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="heritage-page-description">
            {companyInfo?.yearsOfExperience || 78} years of excellence in distillation. 
            From humble beginnings to international recognition, discover the story of Maximus Spirits.
          </p>
        </div>

        {/* Company Overview */}
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20" data-testid="company-overview-section">
          <div>
            <h2 className="text-4xl font-serif mb-6" data-testid="company-overview-title">
              Since {companyInfo?.founded || 1943}
            </h2>
            <p className="text-lg text-muted-foreground mb-6" data-testid="company-overview-description">
              {companyInfo?.description || "Premium Kazakhstani vodkas crafted with heritage and innovation since 1943"}. 
              Founded and launched in 1943, we are one of the first distilleries in the Republic of Kazakhstan.
            </p>
            <p className="text-lg text-muted-foreground mb-6">
              In 2000, our facility was completely re-equipped and modernized in partnership with Krebs-Speichim Company (France), 
              bringing European standards and technology to Kazakhstan.
            </p>
            
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-4 bg-card rounded animate-pulse" />
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-6" data-testid="company-stats">
                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="text-3xl font-bold text-primary mb-2" data-testid="years-experience">
                      {companyInfo?.yearsOfExperience || 78}
                    </div>
                    <div className="text-muted-foreground">Years of Experience</div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="text-3xl font-bold text-primary mb-2" data-testid="distribution-countries">
                      {companyInfo?.distributionCountries || 70}+
                    </div>
                    <div className="text-muted-foreground">Countries</div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
          
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Maximus Distillery Facility" 
              className="rounded-xl shadow-xl w-full"
              data-testid="heritage-facility-image"
            />
            <div className="absolute bottom-4 left-4 bg-background/80 backdrop-blur-sm p-4 rounded" data-testid="heritage-founded-overlay">
              <div className="text-sm text-muted-foreground">Established</div>
              <div className="text-2xl font-bold text-primary">{companyInfo?.founded || 1943}</div>
            </div>
          </div>
        </div>

        {/* Production Excellence */}
        <div className="mb-20" data-testid="production-excellence-section">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-serif mb-4" data-testid="production-title">
              Production Excellence
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="production-description">
              Our state-of-the-art facility combines traditional craftsmanship with modern technology to create exceptional spirits.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6" data-testid="production-steps">
            {productionSteps.map((step, index) => (
              <Card key={index} className="text-center premium-card-hover">
                <CardContent className="p-6">
                  <div className="mb-4 flex justify-center">{step.icon}</div>
                  <h3 className="font-semibold mb-2" data-testid={`step-title-${index}`}>
                    {step.title}
                  </h3>
                  <p className="text-sm text-muted-foreground" data-testid={`step-description-${index}`}>
                    {step.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Features & Certifications */}
        <div className="mb-20" data-testid="features-certifications-section">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-serif mb-4" data-testid="features-title">
              Quality & Certifications
            </h2>
            <p className="text-xl text-muted-foreground" data-testid="features-description">
              Our commitment to excellence is verified by international standards and certifications.
            </p>
          </div>

          {isLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="bg-card rounded-xl h-32 animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6" data-testid="features-grid">
              {companyInfo?.features?.map((feature, index) => (
                <Card key={index} className="premium-card-hover">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-3">
                      <Award className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                      <div>
                        <p className="text-muted-foreground" data-testid={`feature-${index}`}>
                          {feature}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )) || []}
            </div>
          )}
        </div>

        {/* Sustainability */}
        <div className="bg-card p-8 rounded-xl border border-border" data-testid="sustainability-section">
          <div className="text-center mb-8">
            <h2 className="text-4xl font-serif mb-4" data-testid="sustainability-title">
              Sustainable Production
            </h2>
            <p className="text-xl text-muted-foreground" data-testid="sustainability-description">
              ECO GREEN - Our cyclical waste-free production ensures environmental responsibility.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-serif mb-4 text-primary" data-testid="eco-practices-title">
                Environmental Practices
              </h3>
              <p className="text-muted-foreground mb-4" data-testid="eco-practices-description">
                Waste from spirit production is not taken to landfills but is processed, 
                thereby not having an environmentally harmful impact on the environment.
              </p>
              <p className="text-muted-foreground" data-testid="eco-products-description">
                Our distillery is a waste-free production facility. Dry feed additive in the form of dry spent grain 
                is a high-quality product for livestock and poultry farming.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-4" data-testid="sustainability-stats">
              <Card>
                <CardContent className="p-4 text-center">
                  <Leaf className="h-8 w-8 text-primary mx-auto mb-2" />
                  <div className="font-semibold">Zero Waste</div>
                  <div className="text-sm text-muted-foreground">Production</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4 text-center">
                  <Globe className="h-8 w-8 text-primary mx-auto mb-2" />
                  <div className="font-semibold">Eco Certified</div>
                  <div className="text-sm text-muted-foreground">Operations</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
