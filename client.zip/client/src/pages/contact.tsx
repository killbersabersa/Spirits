import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertContactSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Globe, Award, Handshake, Truck, Phone, Mail, MapPin } from "lucide-react";
import { type InsertContact } from "@shared/schema";

const countries = [
  "United States",
  "United Kingdom", 
  "Germany",
  "France",
  "Canada",
  "Australia",
  "Japan",
  "South Korea",
  "China",
  "Russia",
  "Other"
];

export default function Contact() {
  const { toast } = useToast();
  const [isSubmitted, setIsSubmitted] = useState(false);

  const { data: companyInfo } = useQuery({
    queryKey: ["/api/company"],
  });

  const form = useForm<InsertContact>({
    resolver: zodResolver(insertContactSchema),
    defaultValues: {
      companyName: "",
      contactPerson: "",
      email: "",
      country: "",
      experience: "",
    },
  });

  const submitContactMutation = useMutation({
    mutationFn: async (data: InsertContact) => {
      const response = await apiRequest("POST", "/api/contact", data);
      return response.json();
    },
    onSuccess: () => {
      setIsSubmitted(true);
      toast({
        title: "Partnership Inquiry Submitted",
        description: "Thank you for your interest! We'll contact you within 24 hours.",
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Submission Failed",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertContact) => {
    submitContactMutation.mutate(data);
  };

  if (isSubmitted) {
    return (
      <div className="pt-32 pb-20" data-testid="contact-success-page">
        <div className="container mx-auto px-6">
          <div className="max-w-2xl mx-auto text-center">
            <div className="bg-primary w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <Handshake className="h-8 w-8 text-primary-foreground" />
            </div>
            <h1 className="text-4xl font-serif mb-4" data-testid="success-title">
              Thank You for Your Interest
            </h1>
            <p className="text-xl text-muted-foreground mb-8" data-testid="success-description">
              Your partnership inquiry has been submitted successfully. Our team will review your application 
              and contact you within 24 hours to discuss distribution opportunities.
            </p>
            <Button 
              onClick={() => setIsSubmitted(false)} 
              className="btn-secondary"
              data-testid="submit-another-button"
            >
              Submit Another Inquiry
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-20" data-testid="contact-page">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-6xl font-serif mb-4" data-testid="contact-page-title">
              Partner With Excellence
            </h1>
            <p className="text-xl text-muted-foreground" data-testid="contact-page-description">
              Join our global network of distributors and bring premium Kazakhstani spirits to your market.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Partnership Information */}
            <div>
              <h2 className="text-3xl font-serif mb-6" data-testid="partnership-title">
                Distribution Opportunities
              </h2>
              
              <div className="space-y-6 mb-8" data-testid="partnership-benefits">
                <div className="flex items-center space-x-3">
                  <Globe className="h-5 w-5 text-primary" />
                  <span>Available in {companyInfo?.distributionCountries || 70}+ countries worldwide</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Award className="h-5 w-5 text-primary" />
                  <span>Award-winning premium portfolio</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Handshake className="h-5 w-5 text-primary" />
                  <span>Dedicated distributor support</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Truck className="h-5 w-5 text-primary" />
                  <span>Reliable supply chain</span>
                </div>
              </div>
              
              <Card className="bg-background border-border" data-testid="contact-info-card">
                <CardHeader>
                  <CardTitle>Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <Phone className="h-4 w-4 text-primary" />
                    <span className="text-muted-foreground" data-testid="contact-phone">
                      {companyInfo?.contact?.phone || "+7 (7132) 98 80 80"}
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Mail className="h-4 w-4 text-primary" />
                    <span className="text-muted-foreground" data-testid="contact-email">
                      {companyInfo?.contact?.email || "ok@maximusltd.kz"}
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <MapPin className="h-4 w-4 text-primary" />
                    <span className="text-muted-foreground" data-testid="contact-address">
                      {companyInfo?.contact?.address || "41-й разъезд, 129, Актобе, Kazakhstan"}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Contact Form */}
            <Card data-testid="partnership-form-card">
              <CardHeader>
                <CardTitle>Partnership Inquiry Form</CardTitle>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6" data-testid="partnership-form">
                    <div className="grid md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="companyName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Company Name</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Your Company" 
                                {...field} 
                                data-testid="input-company-name"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="contactPerson"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Contact Person</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Full Name" 
                                {...field} 
                                data-testid="input-contact-person"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input 
                                type="email" 
                                placeholder="company@example.com" 
                                {...field} 
                                data-testid="input-email"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="country"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Country/Region</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid="select-country">
                                  <SelectValue placeholder="Select Country" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {countries.map((country) => (
                                  <SelectItem key={country} value={country}>
                                    {country}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="experience"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Distribution Experience</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell us about your distribution network and experience..." 
                              className="h-32" 
                              {...field} 
                              data-testid="textarea-experience"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button 
                      type="submit" 
                      className="w-full btn-primary" 
                      disabled={submitContactMutation.isPending}
                      data-testid="submit-partnership-button"
                    >
                      {submitContactMutation.isPending ? "Submitting..." : "Submit Partnership Inquiry"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
