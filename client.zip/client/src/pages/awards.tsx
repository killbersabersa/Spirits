import { useQuery } from "@tanstack/react-query";
import AwardCard from "@/components/award-card";
import { Card, CardContent } from "@/components/ui/card";
import { Trophy, Award, Star, Medal } from "lucide-react";
import { type Award as AwardType } from "@shared/schema";

export default function Awards() {
  const { data: awards = [], isLoading } = useQuery<AwardType[]>({
    queryKey: ["/api/awards"],
  });

  const { data: companyInfo } = useQuery({
    queryKey: ["/api/company"],
  });

  const goldAwards = awards.filter(award => award.medal.toLowerCase().includes('gold'));
  const silverAwards = awards.filter(award => award.medal.toLowerCase().includes('silver'));
  const otherAwards = awards.filter(award => 
    !award.medal.toLowerCase().includes('gold') && 
    !award.medal.toLowerCase().includes('silver')
  );

  return (
    <div className="pt-32 pb-20" data-testid="awards-page">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-6xl font-serif mb-4" data-testid="awards-page-title">
            International Recognition
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="awards-page-description">
            Our commitment to excellence has been recognized by prestigious international competitions worldwide. 
            Here are the accolades that showcase our dedication to quality and craftsmanship.
          </p>
        </div>

        {/* Awards Statistics */}
        <div className="grid md:grid-cols-4 gap-6 mb-16" data-testid="awards-statistics">
          <Card className="text-center">
            <CardContent className="p-6">
              <Trophy className="h-8 w-8 text-primary mx-auto mb-2" />
              <div className="text-3xl font-bold text-primary" data-testid="gold-awards-count">
                {goldAwards.length}
              </div>
              <div className="text-sm text-muted-foreground">Gold Medals</div>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardContent className="p-6">
              <Medal className="h-8 w-8 text-accent mx-auto mb-2" />
              <div className="text-3xl font-bold text-primary" data-testid="silver-awards-count">
                {silverAwards.length}
              </div>
              <div className="text-sm text-muted-foreground">Silver Medals</div>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardContent className="p-6">
              <Star className="h-8 w-8 text-secondary mx-auto mb-2" />
              <div className="text-3xl font-bold text-primary" data-testid="total-awards-count">
                {awards.length}
              </div>
              <div className="text-sm text-muted-foreground">Total Awards</div>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardContent className="p-6">
              <Award className="h-8 w-8 text-primary mx-auto mb-2" />
              <div className="text-3xl font-bold text-primary" data-testid="competition-brands-count">
                1000+
              </div>
              <div className="text-sm text-muted-foreground">Competing Brands</div>
            </CardContent>
          </Card>
        </div>

        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8" data-testid="awards-loading">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bg-card rounded-xl h-64 animate-pulse" />
            ))}
          </div>
        ) : awards.length === 0 ? (
          <div className="text-center py-16" data-testid="awards-empty-state">
            <h3 className="text-2xl font-serif mb-4">No Awards Available</h3>
            <p className="text-muted-foreground">Our awards and recognition are currently being updated. Please check back soon.</p>
          </div>
        ) : (
          <div className="space-y-12">
            {/* Gold Awards Section */}
            {goldAwards.length > 0 && (
              <div data-testid="gold-awards-section">
                <h2 className="text-3xl font-serif mb-8 text-center">
                  <Trophy className="inline mr-2 text-primary" />
                  Gold Medal Winners
                </h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {goldAwards.map((award) => (
                    <AwardCard key={award.id} award={award} />
                  ))}
                </div>
              </div>
            )}

            {/* Silver Awards Section */}
            {silverAwards.length > 0 && (
              <div data-testid="silver-awards-section">
                <h2 className="text-3xl font-serif mb-8 text-center">
                  <Medal className="inline mr-2 text-accent" />
                  Silver Medal Winners
                </h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {silverAwards.map((award) => (
                    <AwardCard key={award.id} award={award} />
                  ))}
                </div>
              </div>
            )}

            {/* Other Awards Section */}
            {otherAwards.length > 0 && (
              <div data-testid="other-awards-section">
                <h2 className="text-3xl font-serif mb-8 text-center">
                  <Star className="inline mr-2 text-secondary" />
                  Other Recognition
                </h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {otherAwards.map((award) => (
                    <AwardCard key={award.id} award={award} />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Competition Highlight */}
        <div className="mt-16 text-center bg-card p-8 rounded-xl border border-border" data-testid="competition-highlight">
          <h3 className="text-2xl font-serif mb-4">London Spirits Competition Recognition</h3>
          <p className="text-muted-foreground mb-4">
            Our TAIGUN Organic Vodka achieved remarkable success at the London Spirits Competition 2021, 
            scoring 93 points and earning a Gold Medal while competing against over 1,000 international brands.
          </p>
          <div className="inline-flex items-center space-x-6 text-primary">
            <div className="text-center">
              <div className="text-3xl font-bold">93</div>
              <div className="text-sm text-muted-foreground">Points Scored</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">2021</div>
              <div className="text-sm text-muted-foreground">Competition Year</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">1000+</div>
              <div className="text-sm text-muted-foreground">Competing Brands</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
