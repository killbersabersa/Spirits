import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Trophy, Leaf, Wheat, Award } from "lucide-react";
import { type Product } from "@shared/schema";

export default function ProductDetail() {
  const { slug } = useParams();
  
  const { data: product, isLoading, error } = useQuery<Product>({
    queryKey: ["/api/products", slug],
    enabled: !!slug,
  });

  if (isLoading) {
    return (
      <div className="pt-32 pb-20" data-testid="product-detail-loading">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16">
            <div className="h-96 bg-card rounded-xl animate-pulse" />
            <div className="space-y-4">
              <div className="h-8 bg-card rounded animate-pulse" />
              <div className="h-4 bg-card rounded animate-pulse" />
              <div className="h-4 bg-card rounded animate-pulse w-3/4" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="pt-32 pb-20" data-testid="product-detail-error">
        <div className="container mx-auto px-6 text-center">
          <h1 className="text-4xl font-serif mb-4">Product Not Found</h1>
          <p className="text-muted-foreground mb-8">The requested product could not be found.</p>
          <Link href="/products">
            <Button className="btn-primary">Back to Products</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-20" data-testid="product-detail-page">
      <div className="container mx-auto px-6">
        <Link href="/products" className="inline-flex items-center text-primary hover:text-primary/80 mb-8" data-testid="back-to-products-link">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Products
        </Link>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <img 
              src={product.imageUrl} 
              alt={product.name}
              className="w-full rounded-xl shadow-xl"
              data-testid="product-detail-image"
            />
            {product.isOrganic && (
              <div className="absolute top-4 left-4">
                <Badge className="bg-primary text-primary-foreground" data-testid="organic-badge">
                  <Leaf className="mr-1 h-3 w-3" />
                  Organic
                </Badge>
              </div>
            )}
          </div>

          <div className="space-y-6">
            <div>
              <h1 className="text-5xl font-serif mb-4 text-primary" data-testid="product-detail-title">
                {product.name}
              </h1>
              <p className="text-xl text-muted-foreground mb-6" data-testid="product-detail-description">
                {product.description}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-primary" data-testid="product-abv">{product.abv}</div>
                  <div className="text-sm text-muted-foreground">ABV</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-primary" data-testid="product-spirit">{product.spirit}</div>
                  <div className="text-sm text-muted-foreground">Spirit Grade</div>
                </CardContent>
              </Card>
            </div>

            <div>
              <h3 className="text-xl font-serif mb-3">Available Volumes</h3>
              <p className="text-muted-foreground" data-testid="product-volumes">{product.volume}</p>
            </div>

            {product.features && product.features.length > 0 && (
              <div>
                <h3 className="text-xl font-serif mb-3">Features</h3>
                <div className="flex flex-wrap gap-2" data-testid="product-features">
                  {product.features.map((feature, index) => (
                    <Badge key={index} variant="outline">
                      {feature}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {product.awards && product.awards.length > 0 && (
              <div>
                <h3 className="text-xl font-serif mb-3">Awards & Recognition</h3>
                <div className="space-y-2" data-testid="product-awards">
                  {product.awards.map((award, index) => (
                    <div key={index} className="flex items-center space-x-3 p-3 bg-card rounded-lg border border-border">
                      <Trophy className="h-5 w-5 text-primary" />
                      <div>
                        <div className="font-medium">{award.name} {award.year}</div>
                        <div className="text-sm text-muted-foreground">
                          {award.medal}
                          {award.points && ` - ${award.points} Points`}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {product.tastingNotes && (
              <div>
                <h3 className="text-xl font-serif mb-3">Tasting Notes</h3>
                <p className="text-muted-foreground" data-testid="product-tasting-notes">
                  {product.tastingNotes}
                </p>
              </div>
            )}

            {product.heritage && (
              <div>
                <h3 className="text-xl font-serif mb-3">Heritage</h3>
                <p className="text-muted-foreground" data-testid="product-heritage">
                  {product.heritage}
                </p>
              </div>
            )}

            <div className="pt-6">
              <Link href="/contact">
                <Button className="btn-primary w-full" data-testid="contact-distributor-button">
                  Contact for Distribution
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
