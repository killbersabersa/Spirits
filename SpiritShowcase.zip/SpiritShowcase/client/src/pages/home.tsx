import { useQuery } from "@tanstack/react-query";
import HeroSection from "@/components/hero-section";
import ProductCard from "@/components/product-card";
import AwardCard from "@/components/award-card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Wheat, Cog, Leaf } from "lucide-react";
import { type Product, type Award } from "@shared/schema";

export default function Home() {
  const { data: products = [], isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const { data: awards = [], isLoading: awardsLoading } = useQuery<Award[]>({
    queryKey: ["/api/awards"],
  });

  const { data: companyInfo } = useQuery({
    queryKey: ["/api/company"],
  });

  const featuredProducts = products.slice(0, 3);
  const topAwards = awards.slice(0, 3);

  return (
    <div className="pt-20">
      <HeroSection />

      {/* Products Preview Section */}
      <section className="py-20 bg-card" data-testid="products-preview-section">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-serif mb-4" data-testid="products-section-title">
              Our Premium Collection
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="products-section-description">
              Three exceptional spirits, each embodying the spirit of Kazakhstan and the mastery of our distillers.
            </p>
          </div>

          {productsLoading ? (
            <div className="grid md:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-background rounded-xl h-96 animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-8" data-testid="featured-products-grid">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}

          <div className="text-center mt-12">
            <Link href="/products">
              <Button className="btn-primary" data-testid="view-all-products-button">
                View All Products
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Awards Section */}
      <section className="py-20 bg-background" data-testid="awards-preview-section">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-serif mb-4" data-testid="awards-section-title">
              International Recognition
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="awards-section-description">
              Our commitment to excellence has been recognized by prestigious international competitions.
            </p>
          </div>

          {awardsLoading ? (
            <div className="grid md:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-card rounded-xl h-64 animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-8" data-testid="featured-awards-grid">
              {topAwards.map((award) => (
                <AwardCard key={award.id} award={award} />
              ))}
            </div>
          )}

          <div className="mt-16 text-center">
            <div className="inline-flex items-center space-x-4 bg-card p-6 rounded-xl border border-border" data-testid="awards-stats">
              <div className="text-4xl font-bold text-primary" data-testid="competition-count">1000+</div>
              <div className="text-left">
                <div className="font-medium" data-testid="stats-title">Competing Brands</div>
                <div className="text-sm text-muted-foreground" data-testid="stats-subtitle">Worldwide Recognition</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Heritage Preview Section */}
      <section className="py-20 bg-card" data-testid="heritage-preview-section">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="animate-slide-in-left">
              <h2 className="text-5xl font-serif mb-6" data-testid="heritage-section-title">
                {companyInfo?.yearsOfExperience || 78} Years of Excellence
              </h2>
              <p className="text-xl text-muted-foreground mb-8" data-testid="heritage-section-description">
                Since {companyInfo?.founded || 1943}, Maximus Spirits has been pioneering the art of distillation in Kazakhstan. 
                From our modernized facilities to our commitment to organic practices, we represent the perfect blend of tradition and innovation.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4" data-testid="heritage-feature-organic">
                  <div className="bg-primary w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0">
                    <Leaf className="text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Organic Certification</h3>
                    <p className="text-muted-foreground">European and American organic certificates ensure the highest quality standards.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4" data-testid="heritage-feature-technology">
                  <div className="bg-primary w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0">
                    <Cog className="text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Modern Technology</h3>
                    <p className="text-muted-foreground">30-meter distillation columns and complete automation ensure perfect consistency.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4" data-testid="heritage-feature-eco">
                  <div className="bg-primary w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0">
                    <Wheat className="text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Eco-Friendly</h3>
                    <p className="text-muted-foreground">Zero-waste production with all byproducts converted into premium feed additives.</p>
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <Link href="/heritage">
                  <Button className="btn-primary" data-testid="learn-more-heritage-button">
                    Learn More About Our Heritage
                  </Button>
                </Link>
              </div>
            </div>
            
            <div className="relative animate-fade-in">
              <img 
                src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Maximus Distillery" 
                className="rounded-xl shadow-xl w-full" 
                data-testid="heritage-image"
              />
              <div className="absolute bottom-4 left-4 bg-background/80 backdrop-blur-sm p-4 rounded" data-testid="heritage-founded-badge">
                <div className="text-sm text-muted-foreground">Since</div>
                <div className="text-2xl font-bold text-primary">{companyInfo?.founded || 1943}</div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
