import { Card, CardContent } from "@/components/ui/card";
import { Trophy, Award, Star } from "lucide-react";
import { type Award as AwardType } from "@shared/schema";

interface AwardCardProps {
  award: AwardType;
}

export default function AwardCard({ award }: AwardCardProps) {
  const getIcon = () => {
    const medalType = award.medal.toLowerCase();
    if (medalType.includes('gold')) {
      return <Trophy className="text-primary text-2xl" />;
    } else if (medalType.includes('silver')) {
      return <Award className="text-accent text-2xl" />;
    } else {
      return <Star className="text-secondary text-2xl" />;
    }
  };

  const getIconBg = () => {
    const medalType = award.medal.toLowerCase();
    if (medalType.includes('gold')) {
      return "gold-gradient";
    } else if (medalType.includes('silver')) {
      return "bg-accent";
    } else {
      return "bg-secondary";
    }
  };

  return (
    <Card className="bg-card p-8 rounded-xl text-center border border-border premium-card-hover" data-testid={`award-card-${award.id}`}>
      <CardContent className="p-0">
        <div className={`${getIconBg()} w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4`}>
          {getIcon()}
        </div>
        <h3 className="text-xl font-serif mb-2" data-testid={`award-name-${award.id}`}>
          {award.name}
        </h3>
        <p className="text-primary font-medium mb-2" data-testid={`award-medal-${award.id}`}>
          {award.medal}
          {award.points && ` - ${award.points} Points`}
        </p>
        <p className="text-muted-foreground text-sm" data-testid={`award-category-${award.id}`}>
          {award.category} • {award.year}
        </p>
        {award.description && (
          <p className="text-muted-foreground text-xs mt-2" data-testid={`award-description-${award.id}`}>
            {award.description}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
