import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface AgeVerificationProps {
  onVerify: () => void;
}

export default function AgeVerification({ onVerify }: AgeVerificationProps) {
  const [month, setMonth] = useState("");
  const [day, setDay] = useState("");
  const [year, setYear] = useState("");
  const [error, setError] = useState("");

  const months = [
    { value: "01", label: "January" },
    { value: "02", label: "February" },
    { value: "03", label: "March" },
    { value: "04", label: "April" },
    { value: "05", label: "May" },
    { value: "06", label: "June" },
    { value: "07", label: "July" },
    { value: "08", label: "August" },
    { value: "09", label: "September" },
    { value: "10", label: "October" },
    { value: "11", label: "November" },
    { value: "12", label: "December" }
  ];

  const days = Array.from({ length: 31 }, (_, i) => ({
    value: String(i + 1).padStart(2, '0'),
    label: String(i + 1)
  }));

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 100 }, (_, i) => ({
    value: String(currentYear - i),
    label: String(currentYear - i)
  }));

  const handleSubmit = () => {
    if (!month || !day || !year) {
      setError("Please select your complete date of birth");
      return;
    }

    const birthDate = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }

    if (age < 21) {
      setError("You must be 21 or older to enter this site");
      return;
    }

    onVerify();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-95 flex items-center justify-center" data-testid="age-verification-modal">
      <div className="bg-card p-8 rounded-lg max-w-md mx-4 text-center border border-border">
        <div className="mb-6">
          <div className="text-2xl font-serif text-primary mb-2" data-testid="logo-text">
            MAXIMUS SPIRITS
          </div>
          <h2 className="text-2xl font-serif text-accent mb-2" data-testid="welcome-heading">
            Welcome to Maximus Spirits
          </h2>
          <p className="text-muted-foreground mb-6" data-testid="age-requirement-text">
            You must be of legal drinking age to enter this site
          </p>
        </div>
        
        <div className="space-y-4">
          <div className="flex space-x-2">
            <Select onValueChange={setMonth} data-testid="month-select">
              <SelectTrigger className="flex-1">
                <SelectValue placeholder="Month" />
              </SelectTrigger>
              <SelectContent>
                {months.map((month) => (
                  <SelectItem key={month.value} value={month.value}>
                    {month.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select onValueChange={setDay} data-testid="day-select">
              <SelectTrigger className="flex-1">
                <SelectValue placeholder="Day" />
              </SelectTrigger>
              <SelectContent>
                {days.map((day) => (
                  <SelectItem key={day.value} value={day.value}>
                    {day.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select onValueChange={setYear} data-testid="year-select">
              <SelectTrigger className="flex-1">
                <SelectValue placeholder="Year" />
              </SelectTrigger>
              <SelectContent>
                {years.map((year) => (
                  <SelectItem key={year.value} value={year.value}>
                    {year.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {error && (
            <p className="text-destructive text-sm" data-testid="error-message">
              {error}
            </p>
          )}
          
          <Button 
            onClick={handleSubmit} 
            className="w-full btn-primary"
            data-testid="enter-site-button"
          >
            Enter Site
          </Button>
        </div>
        
        <p className="text-xs text-muted-foreground mt-4" data-testid="responsibility-message">
          Drink Responsibly. Must be 21+ in the US.
        </p>
      </div>
    </div>
  );
}
