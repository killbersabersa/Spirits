import { Link } from "wouter";
import { Instagram, Facebook, Twitter } from "lucide-react";

export default function Footer() {
  return (
    <footer className="py-12 bg-background border-t border-border" data-testid="main-footer">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="text-2xl font-serif text-primary mb-4" data-testid="footer-logo">
              MAXIMUS SPIRITS
            </div>
            <p className="text-muted-foreground mb-4" data-testid="footer-description">
              Premium Kazakhstani vodkas crafted with 78 years of heritage and innovation.
            </p>
            <div className="flex space-x-4">
              <a 
                href="https://instagram.com/maximus_spirits_collection" 
                className="text-muted-foreground hover:text-primary transition-colors"
                data-testid="social-instagram"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a 
                href="#" 
                className="text-muted-foreground hover:text-primary transition-colors"
                data-testid="social-facebook"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a 
                href="#" 
                className="text-muted-foreground hover:text-primary transition-colors"
                data-testid="social-twitter"
              >
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4" data-testid="footer-products-heading">Products</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li>
                <Link href="/products/taigun" className="hover:text-primary transition-colors" data-testid="footer-link-taigun">
                  Taigun Organic
                </Link>
              </li>
              <li>
                <Link href="/products/aqqu" className="hover:text-primary transition-colors" data-testid="footer-link-aqqu">
                  Aqqu Premium
                </Link>
              </li>
              <li>
                <Link href="/products/uly-dala" className="hover:text-primary transition-colors" data-testid="footer-link-uly-dala">
                  Uly Dala Heritage
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4" data-testid="footer-company-heading">Company</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li>
                <Link href="/heritage" className="hover:text-primary transition-colors" data-testid="footer-link-about">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/heritage" className="hover:text-primary transition-colors" data-testid="footer-link-heritage">
                  Heritage
                </Link>
              </li>
              <li>
                <Link href="/awards" className="hover:text-primary transition-colors" data-testid="footer-link-awards">
                  Awards
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4" data-testid="footer-contact-heading">Contact</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li data-testid="footer-phone">+7 (7132) 98 80 80</li>
              <li data-testid="footer-email">ok@maximusltd.kz</li>
              <li data-testid="footer-address">Актобе, Kazakhstan</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-border pt-8 mt-8 text-center text-muted-foreground">
          <p data-testid="footer-copyright">
            &copy; 2025 Maximus Spirits. All rights reserved. Drink responsibly.
          </p>
        </div>
      </div>
    </footer>
  );
}
