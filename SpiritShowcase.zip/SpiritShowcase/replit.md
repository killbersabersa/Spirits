# Maximus Spirits Website

## Overview

A premium spirits showcase website for Maximus Spirits, a Kazakhstani vodka company with 78 years of heritage. The application features a modern, dark-themed design showcasing their premium vodka collection including award-winning products like TAIGUN, Aqqu, and Uly Dala. The site includes product displays, awards showcase, company heritage information, and a business contact form for potential distributors and partners.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React with TypeScript**: Modern React 18 application using functional components and hooks
- **Wouter**: Lightweight client-side routing for single-page application navigation
- **Tailwind CSS**: Utility-first CSS framework with custom design system featuring dark theme and premium gold accents
- **Shadcn/ui Components**: Pre-built, accessible UI component library built on Radix UI primitives
- **Vite**: Fast build tool and development server with hot module replacement

### Backend Architecture  
- **Express.js**: Node.js web framework handling REST API routes
- **TypeScript**: Full-stack type safety with shared schemas between client and server
- **In-Memory Storage**: Current implementation uses Map-based storage with pre-populated product and award data
- **RESTful API Design**: Clean API endpoints for products, awards, and contact submissions

### Data Management
- **Drizzle ORM**: Type-safe SQL ORM configured for PostgreSQL with schema definitions
- **Zod Validation**: Runtime type checking and validation for API requests and responses
- **Shared Schemas**: Common TypeScript interfaces used across frontend and backend
- **TanStack Query**: Client-side data fetching, caching, and state management

### UI/UX Design Patterns
- **Age Verification**: Required age gate for alcohol-related content with localStorage persistence
- **Responsive Design**: Mobile-first approach with breakpoint-based layouts
- **Dark Theme**: Premium dark color scheme with gold accents reflecting luxury branding
- **Component-Based Architecture**: Reusable UI components for products, awards, and form elements

### Form Handling
- **React Hook Form**: Performant forms with validation using Zod resolvers
- **Contact Form**: Business inquiry form for distributors with country selection and experience tracking
- **Toast Notifications**: User feedback for form submissions and API interactions

## External Dependencies

### Database
- **PostgreSQL**: Production database (configured via DATABASE_URL)
- **Neon Database**: Serverless PostgreSQL provider integration
- **Drizzle Kit**: Database migrations and schema management

### UI Framework
- **Radix UI**: Headless, accessible component primitives for complex UI elements
- **Lucide Icons**: Comprehensive icon library for consistent visual elements
- **Google Fonts**: Custom typography using Playfair Display and Inter font families

### Development Tools
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Tailwind CSS and Autoprefixer plugins
- **TSX**: TypeScript execution for development server

### Runtime Environment
- **Node.js**: Server runtime with ESM module support
- **Replit Integration**: Platform-specific development plugins and error handling