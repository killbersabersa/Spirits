import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const products = pgTable("products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  shortDescription: text("short_description").notNull(),
  imageUrl: text("image_url").notNull(),
  abv: text("abv").notNull(),
  volume: text("volume").notNull(),
  spirit: text("spirit").notNull(),
  category: text("category").notNull(),
  features: jsonb("features").$type<string[]>().notNull().default([]),
  awards: jsonb("awards").$type<{
    name: string;
    year: number;
    points?: number;
    medal: string;
  }[]>().notNull().default([]),
  isOrganic: boolean("is_organic").notNull().default(false),
  heritage: text("heritage"),
  tastingNotes: text("tasting_notes"),
});

export const awards = pgTable("awards", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  year: integer("year").notNull(),
  category: text("category").notNull(),
  medal: text("medal").notNull(),
  points: integer("points"),
  description: text("description"),
  productId: varchar("product_id").references(() => products.id),
});

export const contacts = pgTable("contacts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyName: text("company_name").notNull(),
  contactPerson: text("contact_person").notNull(),
  email: text("email").notNull(),
  country: text("country").notNull(),
  experience: text("experience").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
});

export const insertAwardSchema = createInsertSchema(awards).omit({
  id: true,
});

export const insertContactSchema = createInsertSchema(contacts).omit({
  id: true,
  createdAt: true,
});

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;
export type InsertAward = z.infer<typeof insertAwardSchema>;
export type Award = typeof awards.$inferSelect;
export type InsertContact = z.infer<typeof insertContactSchema>;
export type Contact = typeof contacts.$inferSelect;
