import { type Product, type InsertProduct, type Award, type InsertAward, type Contact, type InsertContact } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Products
  getProducts(): Promise<Product[]>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;

  // Awards
  getAwards(): Promise<Award[]>;
  getAwardsByProductId(productId: string): Promise<Award[]>;
  createAward(award: InsertAward): Promise<Award>;

  // Contacts
  createContact(contact: InsertContact): Promise<Contact>;
  getContacts(): Promise<Contact[]>;
}

export class MemStorage implements IStorage {
  private products: Map<string, Product>;
  private awards: Map<string, Award>;
  private contacts: Map<string, Contact>;

  constructor() {
    this.products = new Map();
    this.awards = new Map();
    this.contacts = new Map();
    this.initializeData();
  }

  private initializeData() {
    // Initialize products with authentic data from Maximus Spirits
    const taigun: Product = {
      id: "taigun-organic",
      name: "TAIGUN",
      slug: "taigun",
      description: "TAIGUN - vodka from a unique duet of mineral-pure water from the foothills of Alatau and organic wheat, seasoned with Siberian ginseng. Absolute champion of London Spirits Competition, winning gold in three categories.",
      shortDescription: "Award-winning organic vodka infused with Siberian ginseng. London Spirits Competition Gold Medal winner with 93 points.",
      imageUrl: "https://images.unsplash.com/photo-1551538827-9c037cb4f32a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      abv: "40%",
      volume: "0.5L, 0.75L",
      spirit: "Alfa",
      category: "Organic Vodka",
      features: ["Organic", "Siberian Ginseng", "Mineral Water", "Premium Wheat"],
      awards: [
        {
          name: "London Spirits Competition",
          year: 2021,
          points: 93,
          medal: "Gold"
        }
      ],
      isOrganic: true,
      heritage: "Crafted with the finest Prairie Organic NON-GMO Verified Winter Wheat using 75+ years of distilling experience.",
      tastingNotes: "Aromas of pine with a very subtle flavour of vanilla and jasmine. A warming, velvety mouthfeel with rich notes of cocoa and cream."
    };

    const aqqu: Product = {
      id: "aqqu-premium",
      name: "AQQU",
      slug: "aqqu",
      description: "The rustle of golden wheat under the bright, burning sun of Kazakhstan, combined with the highest quality spirit. Qazaq Aragy represents the essence of Kazakhstani craftsmanship.",
      shortDescription: "The rustle of golden wheat under the bright, burning sun of Kazakhstan, combined with the highest quality spirit.",
      imageUrl: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      abv: "40%",
      volume: "0.5L, 0.75L",
      spirit: "Alfa",
      category: "Premium Vodka",
      features: ["Golden Wheat", "Kazakhstan Sun", "Premium Quality", "Traditional"],
      awards: [],
      isOrganic: false,
      heritage: "Representing the golden fields of Kazakhstan under the burning sun, this vodka embodies the spirit of the steppes.",
      tastingNotes: "Clean and crisp with subtle wheat notes and a smooth, warming finish that captures the essence of Kazakhstan's golden fields."
    };

    const ulyDala: Product = {
      id: "uly-dala-heritage",
      name: "ULY DALA",
      slug: "uly-dala",
      description: "Balbals - ancient stone sculptures guarding the steppe expanses. The guardian balbal is depicted on the bottle of the nomad drink - Uly Dala. Like a hospitable host, he holds a cup in one hand, and like a guardian of the steppe, a blade in the other.",
      shortDescription: "Inspired by ancient balbal stone guardians. The spirit of nomads captured in a bottle with traditional Kazakhstani heritage.",
      imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      abv: "40%",
      volume: "0.75L",
      spirit: "Alfa",
      category: "Heritage Vodka",
      features: ["Ancient Heritage", "Balbal Guardians", "Nomadic Spirit", "Traditional"],
      awards: [
        {
          name: "Packaging of the World",
          year: 2022,
          medal: "Featured"
        }
      ],
      isOrganic: false,
      heritage: "Inspired by the mysterious balbal stones guarding the steppes of Kazakhstan since the Bronze Age, dating back some 5,000 years. The bottle design features the guardian balbal as both hospitable host and steppe protector.",
      tastingNotes: "Rich and complex with earthy undertones that reflect the ancient steppes. Smooth texture with hints of spice and a long, satisfying finish."
    };

    this.products.set(taigun.id, taigun);
    this.products.set(aqqu.id, aqqu);
    this.products.set(ulyDala.id, ulyDala);

    // Initialize awards
    const londonSpirits: Award = {
      id: "london-spirits-2021",
      name: "London Spirits Competition 2021",
      year: 2021,
      category: "Vodka",
      medal: "Gold",
      points: 93,
      description: "TAIGUN Organic Vodka won gold medal with 93 points, competing against 1000+ brands worldwide.",
      productId: "taigun-organic"
    };

    const europeWineSpirits: Award = {
      id: "europe-wine-spirits-2020",
      name: "Europe Wine & Spirits Trophy International 2020",
      year: 2020,
      category: "Vodka",
      medal: "Best in Category",
      points: null,
      description: "Recognized for excellence in vodka production at this highly regarded international event.",
      productId: "taigun-organic"
    };

    const laInternational: Award = {
      id: "la-international-2017",
      name: "Los Angeles International Spirits Competition 2017",
      year: 2017,
      category: "Spirits",
      medal: "Silver",
      points: null,
      description: "International recognition for quality and craftsmanship.",
      productId: "taigun-organic"
    };

    this.awards.set(londonSpirits.id, londonSpirits);
    this.awards.set(europeWineSpirits.id, europeWineSpirits);
    this.awards.set(laInternational.id, laInternational);
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(p => p.slug === slug);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = { 
      ...insertProduct, 
      id,
      features: insertProduct.features || []
    };
    this.products.set(id, product);
    return product;
  }

  async getAwards(): Promise<Award[]> {
    return Array.from(this.awards.values());
  }

  async getAwardsByProductId(productId: string): Promise<Award[]> {
    return Array.from(this.awards.values()).filter(a => a.productId === productId);
  }

  async createAward(insertAward: InsertAward): Promise<Award> {
    const id = randomUUID();
    const award: Award = { 
      ...insertAward, 
      id,
      points: insertAward.points || null,
      description: insertAward.description || null,
      productId: insertAward.productId || null
    };
    this.awards.set(id, award);
    return award;
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = randomUUID();
    const contact: Contact = { 
      ...insertContact, 
      id,
      createdAt: new Date().toISOString()
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async getContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values());
  }
}

export const storage = new MemStorage();
