import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Products API
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:slug", async (req, res) => {
    try {
      const { slug } = req.params;
      const product = await storage.getProductBySlug(slug);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  // Awards API
  app.get("/api/awards", async (req, res) => {
    try {
      const awards = await storage.getAwards();
      res.json(awards);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch awards" });
    }
  });

  app.get("/api/awards/product/:productId", async (req, res) => {
    try {
      const { productId } = req.params;
      const awards = await storage.getAwardsByProductId(productId);
      res.json(awards);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product awards" });
    }
  });

  // Contact form submission
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(validatedData);
      res.status(201).json({ 
        message: "Contact form submitted successfully", 
        id: contact.id 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid form data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to submit contact form" });
    }
  });

  // Company information endpoint
  app.get("/api/company", async (req, res) => {
    try {
      const companyInfo = {
        name: "Maximus Spirits",
        founded: 1943,
        yearsOfExperience: new Date().getFullYear() - 1943,
        location: "Aktobe, Kazakhstan",
        description: "Premium Kazakhstani vodkas crafted with heritage and innovation since 1943",
        features: [
          "Organic Certification (European and American)",
          "30-meter distillation columns",
          "Zero-waste ECO GREEN production",
          "Complete automation of all operational cycles",
          "Alfa spirit - highest quality available"
        ],
        contact: {
          phone: "+7 (7132) 98 80 80",
          email: "ok@maximusltd.kz",
          address: "41-й разъезд, 129, г. Актобе, D00M6X4, Казахстан"
        },
        distributionCountries: 70,
        totalAwards: 6
      };
      
      res.json(companyInfo);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch company information" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
